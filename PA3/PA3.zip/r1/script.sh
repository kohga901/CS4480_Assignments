#!/bin/bash

service frr restart

# Start the container
bash