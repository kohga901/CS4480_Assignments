#!/bin/bash

service frr restart

# Keep container running
bash